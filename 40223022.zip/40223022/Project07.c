// Nazanin Zahra Taghizadeh 40223022
#include <stdio.h>
int main(void)
{
    int n;
    printf("Enter the number of words:\t");
    scanf("%d",&n);
    char w1[n][50];
    char w2[n][50];
    int len1[n];
    int len2[n];
    int j=0;
    int m=0;
    int count=0;
    int end=0;
    for (int i=0; i<n ; i++)
        scanf("%s %s",&w1[i], &w2[i]);
    while (j<n)
    {
        while (w1[j][m]!='\0')
        {
            count+=1;
            ++m;
        }
        len1[j]=count;
        count=0;
        m=0;
        while (w2[j][m]!='\0')
        {
            count+=1;
            ++m;
        }
        len2[j]=count;
        count=0;
        m=0;
        ++j;
    }
    getchar();
    char sentence[1000];
    printf("Please enter your sentece if you want to show the end of your sentece add 0: \t");
    for (int o=0; o<1000 ; ++o)
    {
        scanf("%c",&sentence[o]);
        if (sentence[o]=='0')
        {
            end=o;
            break;
        }
    }
    int u=0;
    int h=0;
    int t=-1;
    int firstword;
    int a=0;
    char alphabet[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    char al[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    for (int x=0; x<26; x++)
    {
    if (w1[0][0]==al[x])
    for (int e=0; e<end ; e++)
    {
        if (sentence[e]!=' ')
        {
            if (sentence[e]==al[x])
            {
            sentence[e]=al[x];
            e++;
            }
            else 
            e++;
        }
        else 
        e++;
    }
    
    else if (w1[0][0]==alphabet[x])
        for (int e=0; e<end ; e++)
    {
        if (sentence[e]!=' ')
        {
        if (sentence[e]==alphabet[x])
        {
            sentence[e]=alphabet[x];
            e++;
        }
        else 
        e++;
        }

        else 
        e++;
    }
    }
    

    while (t!=end)
    {   
        if ( t==-1 || sentence[t]==' ')
        {
            t++;
            firstword=t;
            continue;
        }
        if (sentence[t]!=w1[u][h])
        {
        ++u;
        h=0;
        t=firstword;
        }
        else
        { 
        ++t;
        ++h;
        if ((h+1)==len1[u])
         {
            if (len1[u]>len2[u])
            printf("%s ",&w2[u]);
            else
            printf("%s ",w1[u]);
            h=0;
            u=0;
            t+=1;
         }
        }
    }
   return 0;
}


     










  